

t =int(input("Digite o tempo que você deseja para desloca o robo: "))
velocidade =int(input("Digite a velocidade  que  deseja para desloca o robo: "))

velocidadeDerivada =


calcularDistancia = 2 * t **2 + 3*t

if t >= 0 and t <= 10:
     print(calcularDistancia)

if velocidade >= 0 and velocidade <= 10 :
  print(velocidadeDerivada)

else:
    print("não foi possivel calcular com os dados fornecidos")
